import { HeroesList } from "../components/HeroesList"

export const DcPage = () => {
  return (
    <>
      <h1>Dc Comics</h1>
      <hr />

      <HeroesList publisher="DC Comics" />
    </>
  )
}
