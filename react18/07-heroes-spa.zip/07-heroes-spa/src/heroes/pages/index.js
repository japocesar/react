export * from './DcPage';
export * from './MarvelPage';
export * from './HeroPage';
export * from './SearchPage';