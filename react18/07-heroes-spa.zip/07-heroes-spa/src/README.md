## Installation

Install the dependencies and devDependencies and start the server.

```sh
yarn
yarn dev
```

Open the "Local" address on your browser